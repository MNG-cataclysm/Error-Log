# Fantasy
 
 A collaboration between a small group of CDDA modders, Fantasy (name still being worked on), will be just what it sounds like, a fantasy world undergoing some decidedly rough times with lots of monsters rising up and making trouble. Adventures, quests, dungeons, you name it, it'll be in there.
 
 Intended to be run alongside of XP and Magic Unbound to provide a much more RPGish experience.
